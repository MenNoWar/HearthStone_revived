# Hearthstone

Hearthstone adds a consumable stone that brings you back home.

- You can set any bed of yours to be the Hearthstone stone "spawn" point
- You can craft hearthstone in workbench with configurable items
- Now the hearthstone is a heart

It must be installed in the server and the client.